# Facial-Emotion-Detection
Developed a powerful facial emotion detection system using deep learning to accurately classify emotions such as 😊 Happy, 😢 Sad, 😡 Angry, 😨 Fear, 😐 Neutral, 🤢 Disgust, and 😲 Surprise. Utilized the FER-2013 dataset and built the model using Keras, TensorFlow, and Python.
